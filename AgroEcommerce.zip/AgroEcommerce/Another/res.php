<?php
require_once("../includes/db.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $phone = trim($_POST["phone"]);
    $address = trim($_POST["address"]);
    $user_type = $_POST["user_type"];
    $password = $_POST["password"];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $error = "Email is already registered.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (name, email, phone, address, user_type, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $email, $phone, $address, $user_type, $hashed_password);
        
        if ($stmt->execute()) {
            header("Location: login.php?success=1");
            exit();
        } else {
            $error = "Registration failed. Try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register | AgroEcommerce</title>
    <link rel="stylesheet" href="../assets/css/register.css">
</head>
<body>
    <?php include("../includes/header.php"); ?>

    <div class="container">
        <h2>Register</h2>
        <?php if (!empty($error)): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="" method="POST" class="form">
            <label for="name">Full Name:</label>
            <input type="text" name="name" required>

            <label for="email">Email:</label>
            <input type="email" name="email" required>

            <label for="phone">Phone Number:</label>
            <input type="text" name="phone" required>

            <label for="address">Address:</label>
            <textarea name="address" required></textarea>

            <label for="user_type">Register As:</label>
            <select name="user_type" required>
                <option value="">--Select--</option>
                <option value="buyer">Buyer</option>
                <option value="seller">Seller</option>
                <option value="both">Both</option>
            </select>

            <label for="password">Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Register</button>
        </form>
    </div>

    <?php include("../includes/footer.php"); ?>
</body>
</html>



<Checkout class="php"><?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    echo "<p>Please <a href='login.php'>login as a buyer</a> to checkout.</p>";
    include('../includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch cart
$sql = "SELECT c.id as cart_id, p.id as product_id, p.title, p.price, c.quantity
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = $user_id";
$cart_items = $conn->query($sql);

if ($cart_items->num_rows == 0) {
    echo "<p>Your cart is empty. <a href='product_list.php'>Browse Products</a></p>";
    include('../includes/footer.php');
    exit();
}

// Place order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->begin_transaction();

    try {
        // Calculate total
        $total = 0;
        while ($item = $cart_items->fetch_assoc()) {
            $total += $item['price'] * $item['quantity'];
        }

        // Insert order
        $conn->query("INSERT INTO orders (user_id, total_amount) VALUES ($user_id, $total)");
        $order_id = $conn->insert_id;

        // Insert order items
        $cart_items->data_seek(0); // reset result pointer
        while ($item = $cart_items->fetch_assoc()) {
            $p_id = $item['product_id'];
            $qty = $item['quantity'];
            $price = $item['price'];

            $conn->query("INSERT INTO order_items (order_id, product_id, quantity, price)
                          VALUES ($order_id, $p_id, $qty, $price)");
        }

        // Clear cart
        $conn->query("DELETE FROM cart WHERE user_id = $user_id");

        $conn->commit();
        echo "<p>✅ Order placed successfully! <a href='my_orders.php'>View Orders</a></p>";
    } catch (Exception $e) {
        $conn->rollback();
        echo "<p>❌ Order failed. Try again later.</p>";
    }

    include('../includes/footer.php');
    exit();
}
?>

<main class="container">
    <h2>Checkout</h2>

    <p>You're about to place an order with the following items:</p>

    <form method="POST">
        <ul>
            <?php
            $cart_items->data_seek(0);
            $total = 0;
            while ($item = $cart_items->fetch_assoc()):
                $subtotal = $item['price'] * $item['quantity'];
                $total += $subtotal;
            ?>
                <li>
                    <?php echo $item['title']; ?> - Qty: <?php echo $item['quantity']; ?> - ₹<?php echo $subtotal; ?>
                </li>
            <?php endwhile; ?>
        </ul>

        <p><strong>Total Amount:</strong> ₹<?php echo number_format($total, 2); ?></p>

        <button type="submit">Place Order</button>
    </form>
</main>

<?php include('../includes/footer.php'); ?>
</Checkout>
<?php
session_start();
include('includes/db.php');
include('includes/header.php');

if (!isset($_SESSION['user_id'])) {
    echo "<p>Please <a href='pages/login.php'>login</a> to access your profile.</p>";
    include('includes/footer.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Fetch user details
$query = $conn->prepare("SELECT * FROM users WHERE id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
$user = $result->fetch_assoc();

// Update profile
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars(trim($_POST['name']));
    $email = htmlspecialchars(trim($_POST['email']));
    $phone = htmlspecialchars(trim($_POST['phone']));
    $address = htmlspecialchars(trim($_POST['address']));

    // Optional: validate inputs here

    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, phone = ?, address = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $name, $email, $phone, $address, $user_id);
    $stmt->execute();

    $message = "✅ Profile updated successfully.";

    // Refresh updated user data
    $query = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $query->bind_param("i", $user_id);
    $query->execute();
    $user = $query->get_result()->fetch_assoc();
}
?>

<main class="container">
    <h2>🙍‍♂️ My Profile</h2>

    <?php if ($message): ?>
        <p style="color: green;"><?= $message; ?></p>
    <?php endif; ?>

    <form method="POST" class="profile-form">
        <label>Name:</label>
        <input type="text" name="name" required value="<?= htmlspecialchars($user['name']); ?>">

        <label>Email:</label>
        <input type="email" name="email" required value="<?= htmlspecialchars($user['email']); ?>">

        <label>Phone:</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($user['phone']); ?>">

        <label>Address:</label>
        <textarea name="address" required><?= htmlspecialchars($user['address']); ?></textarea>

        <button type="submit">Update Profile</button>
    </form>
</main>

<style>
.container {
    padding: 20px;
    max-width: 500px;
    margin: auto;
}
.profile-form {
    display: flex;
    flex-direction: column;
}
.profile-form label {
    margin-top: 10px;
}
.profile-form input, .profile-form textarea {
    padding: 8px;
    margin-top: 5px;
    border-radius: 6px;
    border: 1px solid #ccc;
}
.profile-form button {
    margin-top: 15px;
    padding: 10px;
    background: #28a745;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.profile-form button:hover {
    background: #218838;
}
</style>

<?php include('includes/footer.php'); ?>
<Mailer class="php">
    <?php
require_once '../includes/PHPMailer/PHPMailer.php';
require_once '../includes/PHPMailer/SMTP.php';
require_once '../includes/PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($toEmail, $subject, $bodyHtml, $toName)
{
    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = 2; // Debug mode
        $mail->Debugoutput = 'echo';

        // SMTP settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 's23_shaikh_irafan@mgmcen.ac.in';
        $mail->Password   = 'oecy ydlu rzps qihz'; // App password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;



        // Sender & recipient
        $mail->setFrom('s23_shaikh_irafan@mgmcen.ac.in', 'AgroTrade');
        $mail->addAddress($toEmail, $toName);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email sending failed: {$mail->ErrorInfo}");
        return false;
    }
}

</Mailer>
profile
<Rate>
<?php include('../includes/header.php'); ?>

<main class="container">
    <h2>📈 Live Mandi Rates (Mock Data)</h2>
    <p>Prices listed below are representative and updated daily.</p>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Crop</th>
                    <th>Market</th>
                    <th>Min Price (₹/quintal)</th>
                    <th>Max Price (₹/quintal)</th>
                    <th>Modal Price (₹/quintal)</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>Wheat</td><td>Delhi</td><td>1900</td><td>2100</td><td>2000</td></tr>
                <tr><td>Rice</td><td>Lucknow</td><td>1800</td><td>2000</td><td>1900</td></tr>
                <tr><td>Onion</td><td>Nashik</td><td>500</td><td>900</td><td>700</td></tr>
                <tr><td>Tomato</td><td>Pune</td><td>600</td><td>950</td><td>800</td></tr>
            </tbody>
        </table>
    </div>
</main>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #f9f9f9;
    }

    main.container {
        padding: 20px;
        max-width: 1000px;
        margin: auto;
    }

    h2 {
        text-align: center;
        color: #2f5d2f;
        margin-bottom: 10px;
    }

    p {
        text-align: center;
        margin-bottom: 25px;
        font-size: 15px;
        color: #444;
    }

    .table-container {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: auto;
        min-width: 600px;
        background-color: white;
    }

    table, th, td {
        border: 1px solid #ccc;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: #e8f5e9;
        color: #2e7d32;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    @media (max-width: 768px) {
        h2 {
            font-size: 22px;
        }

        p {
            font-size: 14px;
        }

        th, td {
            padding: 10px 6px;
            font-size: 13px;
        }
    }

    @media (max-width: 480px) {
        table {
            font-size: 12px;
            min-width: unset;
        }

        th, td {
            padding: 8px 4px;
        }

        main.container {
            padding: 10px;
        }
    }
</style>

<?php include('../includes/footer.php'); ?>
</Rate>
<login>
<?php
session_start();
include('../includes/db.php');

$message = '';
$_SESSION['user_email'] = $user['email']; // Add this


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            // ✅ Store info in session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['user_name'] = $user['name'];

            // ✅ Redirect to correct page
            if ($user['user_type'] === 'farmer') {
                header("Location: sell.php");
            } else {
                header("Location: product_list.php");
            }
            exit();
        } else {
            $message = "Invalid password.";
        }
    } else {
        $message = "User not found.";
    }
}
include('../includes/header.php');
?>


<main class="container">
    <h2>Login</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" class="login-form">
        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a>.</p>
    <p><a href="forgot_password.php">Forgot Password?</a></p>

</main>

<style>
    .login-form {
        max-width: 400px;
        margin: auto;
        display: flex;
        flex-direction: column;
    }

    .login-form input {
        padding: 8px;
        margin: 10px 0;
    }

    .message {
        color: red;
        font-weight: bold;
    }
</style>

<?php include('../includes/footer.php'); ?>
</login>
<Mandirate.php><?php include('../includes/header.php'); ?>

<main class="container">
    <h2>📈 Live Mandi Rates (Mock Data)</h2>
    <p>Prices listed below are representative and updated daily.</p>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Crop</th>
                    <th>Market</th>
                    <th>Min Price (₹/quintal)</th>
                    <th>Max Price (₹/quintal)</th>
                    <th>Modal Price (₹/quintal)</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>Wheat</td><td>Delhi</td><td>1900</td><td>2100</td><td>2000</td></tr>
                <tr><td>Rice</td><td>Lucknow</td><td>1800</td><td>2000</td><td>1900</td></tr>
                <tr><td>Onion</td><td>Nashik</td><td>500</td><td>900</td><td>700</td></tr>
                <tr><td>Tomato</td><td>Pune</td><td>600</td><td>950</td><td>800</td></tr>
            </tbody>
        </table>
    </div>
</main>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', sans-serif;
        background: #f9f9f9;
    }

    main.container {
        padding: 20px;
        max-width: 1000px;
        margin: auto;
    }

    h2 {
        text-align: center;
        color: #2f5d2f;
        margin-bottom: 10px;
    }

    p {
        text-align: center;
        margin-bottom: 25px;
        font-size: 15px;
        color: #444;
    }

    .table-container {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin: auto;
        min-width: 600px;
        background-color: white;
    }

    table, th, td {
        border: 1px solid #ccc;
    }

    th, td {
        padding: 12px;
        text-align: center;
    }

    th {
        background-color: #e8f5e9;
        color: #2e7d32;
        font-weight: 600;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:hover {
        background-color: #f1f1f1;
    }

    @media (max-width: 768px) {
        h2 {
            font-size: 22px;
        }

        p {
            font-size: 14px;
        }

        th, td {
            padding: 10px 6px;
            font-size: 13px;
        }
    }

    @media (max-width: 480px) {
        table {
            font-size: 12px;
            min-width: unset;
        }

        th, td {
            padding: 8px 4px;
        }

        main.container {
            padding: 10px;
        }
    }
</style>

<?php include('../includes/footer.php'); ?>
</Mandirate.php>
