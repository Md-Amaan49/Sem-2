<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

// ✅ Admin Check
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer' || $_SESSION['user_email'] !== 'sheikhirafanrashid@gmail.com') {
    echo "<p>Access denied. Only admin can access this page.</p>";
    include('../includes/footer.php');
    exit();
}

$message = '';

// ✅ Delete Product and Related Data
if (isset($_GET['delete'])) {
    $pid = intval($_GET['delete']);

    // Get image filename before deletion
    $imgResult = $conn->query("SELECT image FROM products WHERE id = $pid");
    $imgRow = $imgResult->fetch_assoc();

    // Delete related entries
    $conn->query("DELETE FROM cart WHERE product_id = $pid");
    $conn->query("DELETE FROM order_items WHERE product_id = $pid");

    // Delete product
    if ($conn->query("DELETE FROM products WHERE id = $pid")) {
        // Delete image file if it exists
        if ($imgRow && file_exists("../uploads/" . $imgRow['image'])) {
            unlink("../uploads/" . $imgRow['image']);
        }
        $message = "✅ Product deleted successfully.";
    } else {
        $message = "❌ Failed to delete product.";
    }
}

// ✅ Fetch Products
$result = $conn->query("SELECT p.id, p.title, p.price, p.image, u.name AS farmer_name
                        FROM products p
                        JOIN users u ON p.farmer_id = u.id
                        ORDER BY p.created_at DESC");
?>

<main class="container">
    <h2>🌾 Manage Products</h2>
    <?php if ($message) echo "<div class='alert'>$message</div>"; ?>

    <table>
        <thead>
            <tr>
                <th>Image</th>
                <th>Title</th>
                <th>Price (₹)</th>
                <th>Farmer</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><img src="../uploads/<?= htmlspecialchars($row['image']); ?>" width="80"></td>
                <td><?= htmlspecialchars($row['title']); ?></td>
                <td><?= number_format($row['price']); ?></td>
                <td><?= htmlspecialchars($row['farmer_name']); ?></td>
                <td>
                    <a href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this product?')">❌ Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</main>

<style>
.container {
    padding: 20px;
}
.alert {
    background-color: #d4edda;
    color: #155724;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #c3e6cb;
    border-radius: 5px;
    text-align: center;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
table, th, td {
    border: 1px solid #ccc;
}
th, td {
    padding: 12px;
    text-align: center;
}
th {
    background-color: #f4f4f4;
}
img {
    max-height: 80px;
    border-radius: 8px;
}
</style>

<?php include('../includes/footer.php'); ?>
