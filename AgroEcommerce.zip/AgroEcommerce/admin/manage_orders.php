<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

// Admin check
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer' || $_SESSION['user_email'] !== 'sheikhirafanrashid@gmail.com') {
    echo "<p>Access denied. Only admin can access this page.</p>";
    include('../includes/footer.php');
    exit();
}

// Handle order status update
if (isset($_GET['mark_shipped'])) {
    $order_id = intval($_GET['mark_shipped']);
    $conn->query("UPDATE orders SET status = 'Shipped' WHERE id = $order_id");
    echo "<p>Order marked as shipped.</p>";
}

// Fetch orders with product and buyer info
$sql = "SELECT o.id AS order_id, o.status, o.order_date, o.total_amount, u.name AS buyer_name,
               p.title AS product_title, oi.quantity
        FROM orders o
        JOIN users u ON o.user_id = u.id
        JOIN order_items oi ON oi.order_id = o.id
        JOIN products p ON oi.product_id = p.id
        ORDER BY o.order_date DESC";

$result = $conn->query($sql);

if (!$result) {
    echo "<p style='color:red;'>Error fetching orders: " . $conn->error . "</p>";
    include('../includes/footer.php');
    exit();
}
?>

<main class="container">
    <h2>📦 Manage Orders</h2>

    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product</th>
                <th>Buyer</th>
                <th>Quantity</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['order_id']; ?></td>
                <td><?= htmlspecialchars($row['product_title']); ?></td>
                <td><?= htmlspecialchars($row['buyer_name']); ?></td>
                <td><?= $row['quantity']; ?></td>
                <td>₹<?= number_format($row['total_amount'], 2); ?></td>
                <td><?= ucfirst($row['status']); ?></td>
                <td><?= $row['order_date']; ?></td>
                <td>
                    <?php if ($row['status'] === 'pending'): ?>
                        <a href="?mark_shipped=<?= $row['order_id']; ?>" onclick="return confirm('Mark this order as shipped?')">🚚 Mark Shipped</a>
                    <?php else: ?>
                        ✅ Shipped
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</main>

<style>
.container {
    padding: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
table, th, td {
    border: 1px solid #ccc;
}
th, td {
    padding: 10px;
    text-align: center;
}
th {
    background-color: #eaeaea;
}
</style>

<?php include('../includes/footer.php'); ?>
