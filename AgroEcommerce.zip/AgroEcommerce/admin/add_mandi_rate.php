<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');
// ✅ Restrict access only to admin buyer with specific email
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer' || $_SESSION['user_email'] !== 'sheikhirafanrashid@gmail.com') {
    echo "<p style='color: red; padding: 20px;'>Access denied. Only admin can access this page.</p>";
    include('../includes/footer.php');
    exit();
}

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $crop = $conn->real_escape_string($_POST["crop"]);
    $market = $conn->real_escape_string($_POST["market"]);
    $min_price = floatval($_POST["min_price"]);
    $max_price = floatval($_POST["max_price"]);
    $modal_price = floatval($_POST["modal_price"]);

    $sql = "INSERT INTO mandi_rates (crop, market, min_price, max_price, modal_price, date_added)
            VALUES ('$crop', '$market', $min_price, $max_price, $modal_price, NOW())";

    if ($conn->query($sql)) {
        $message = "✅ Mandi rate added successfully!";
    } else {
        $message = "❌ Error: " . $conn->error;
    }
}
?>

<main class="container">
    <h2>Add Mandi Rate</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" class="rate-form">
        <label>Crop Name:</label>
        <input type="text" name="crop" required>

        <label>Market (City):</label>
        <input type="text" name="market" required>

        <label>Min Price (₹/quintal):</label>
        <input type="number" name="min_price" step="0.01" required>

        <label>Max Price (₹/quintal):</label>
        <input type="number" name="max_price" step="0.01" required>

        <label>Modal Price (₹/quintal):</label>
        <input type="number" name="modal_price" step="0.01" required>

        <button type="submit">Add Rate</button>
    </form>
</main>

<style>
.container {
    max-width: 600px;
    margin: 30px auto;
    background: #fff;
    padding: 25px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

.rate-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.rate-form label {
    font-weight: bold;
}

.rate-form input, .rate-form button {
    padding: 10px;
    font-size: 16px;
}

.rate-form button {
    background-color: green;
    color: white;
    border: none;
    cursor: pointer;
}

.message {
    font-weight: bold;
    color: green;
}

@media (max-width: 500px) {
    .container {
        padding: 15px;
    }

    .rate-form input, .rate-form button {
        font-size: 14px;
        padding: 8px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>
