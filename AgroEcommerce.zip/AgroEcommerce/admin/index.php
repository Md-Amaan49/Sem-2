<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

// Ensure only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer' || $_SESSION['user_email'] !== 'sheikhirafanrashid@gmail.com') {
    echo "<p>Access denied. Only admin can access this page.</p>";
    include('../includes/footer.php');
    exit();
}
?>

<main class="container">
    <h2>👨‍💼 Admin Dashboard</h2>
    <p>Welcome, Admin! Use the options below to manage the platform.</p>

    <div class="admin-links">
        <a href="manage_users.php" class="admin-box">👥 Manage Users</a>
        <a href="manage_products.php" class="admin-box">🌾 Manage Products</a>
        <a href="manage_orders.php" class="admin-box">📦 Manage Orders</a>
        <a href="add_mandi_rate.php" class="admin-box">Add Mandi Rate</a>
    </div>
</main>

<style>
.container {
    padding: 20px;
}
.admin-links {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
    margin-top: 30px;
}
.admin-box {
    flex: 1 1 200px;
    padding: 20px;
    text-align: center;
    background: #e0ffe0;
    border: 1px solid #ccc;
    border-radius: 12px;
    text-decoration: none;
    font-size: 18px;
    font-weight: bold;
    transition: background 0.2s;
}
.admin-box:hover {
    background: #c6f3c6;
}
</style>

<?php include('../includes/footer.php'); ?>
