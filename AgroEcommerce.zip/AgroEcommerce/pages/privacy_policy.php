<?php include('../includes/header.php'); ?>
<main class="container">
    <h2>Privacy Policy</h2>
    <p>Your privacy is important to us. We ensure the safety of your personal information. Here's how we use and protect your data:</p>
    <ul>
        <li>We collect only necessary data like name, email, phone, and address for order processing and communication.</li>
        <li>We never share or sell your data to third parties.</li>
        <li>Your data is stored securely using encryption and protected server environments.</li>
    </ul>
    <p>By using our site, you agree to our Privacy Policy.</p>
</main>

<style>
.container {
    max-width: 900px;
    margin: auto;
    padding: 20px;
    font-family: Arial, sans-serif;
}
</style>
<?php include('../includes/footer.php'); ?>
