<?php
include('../includes/db.php');
include('../includes/header.php');

$search = isset($_GET['query']) ? trim($conn->real_escape_string($_GET['query'])) : '';
?>

<main class="container">
    <h2>Search Results for '<?= htmlspecialchars($search) ?>'</h2>

    <?php if (!empty($search)): ?>
        <?php
        $sql = "SELECT * FROM products WHERE title LIKE '%$search%' OR description LIKE '%$search%'";
        $result = $conn->query($sql);
        ?>
        
        <?php if ($result && $result->num_rows > 0): ?>
            <div class="product-grid">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="product-card">
                        <img src="/AgroEcommerce/uploads/<?= $row['image']; ?>" alt="<?= htmlspecialchars($row['title']); ?>">
                        <h3><?= htmlspecialchars($row['title']); ?></h3>
                        <p class="price">₹ <?= number_format($row['price'], 2); ?></p>
                        <a href="product_detail.php?id=<?= $row['id']; ?>" class="buy-btn">View & Buy</a>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="no-result">No products found matching your search.</p>
        <?php endif; ?>
    <?php else: ?>
        <p class="no-result">Please enter a search query.</p>
    <?php endif; ?>
</main>

<style>
.container {
    max-width: 1200px;
    margin: 2px;
    padding: 30px 15px;
    font-family: 'Segoe UI', sans-serif;
}

h2 {
    margin-bottom: 25px;
    font-size: 26px;
    color: #2c3e50;
    text-align: center;
}

.product-grid {
    display: flex;
    justify-self: center;
    flex-wrap: wrap;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
}

.product-card {
    max-height: 500px;
    background: #fff;
    border: 1px solid #ddd;
    border-radius: 10px;
    padding: 15px;
    text-align: center;
    transition: 0.3s ease;
    box-shadow: 0 2px 5px rgba(0,0,0,0.05);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.product-card:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transform: scale(1.02);
}

.product-card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 10px;
}

.product-card h3 {
    font-size: 18px;
    color: #333;
    margin-bottom: 8px;
}

.price {
    font-weight: bold;
    font-size: 16px;
    color: #28a745;
    margin-bottom: 10px;
}

.buy-btn {
    display: inline-block;
    padding: 10px 18px;
    background-color: #007bff;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
    transition: background 0.3s;
}

.buy-btn:hover {
    background-color: #0056b3;
}

.no-result {
    font-size: 18px;
    color: #888;
    text-align: center;
}

/* Responsive tweaks */
@media screen and (max-width: 768px) {
    h2 {
        font-size: 22px;
    }

    .product-card {
        padding: 10px;
    }

    .buy-btn {
        width: 100%;
        font-size: 15px;
    }
}

@media screen and (max-width: 480px) {
    .product-card img {
        height: 150px;
    }

    .product-card h3 {
        font-size: 16px;
    }

    .price {
        font-size: 15px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>
