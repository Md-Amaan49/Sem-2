<?php
session_start();
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

include('../includes/db.php');

// Ensure user is logged in and is a buyer
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'buyer') {
    header('Location: ../pages/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id']);
$quantity = intval($_POST['quantity']);

// Check if product already in cart for this user
$check = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
$check->bind_param("ii", $user_id, $product_id);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    // If already exists, update quantity
    $check->bind_result($cart_id, $existing_qty);
    $check->fetch();
    $new_qty = $existing_qty + $quantity;

    $update = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $update->bind_param("ii", $new_qty, $cart_id);
    $update->execute();
} else {
    // Else, insert new cart row
    $insert = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
    $insert->bind_param("iii", $user_id, $product_id, $quantity);
    $insert->execute();
}

header('Location: ../pages/cart.php?added=1');
exit();
