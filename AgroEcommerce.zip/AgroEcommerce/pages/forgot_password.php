<?php
session_start();
include('../includes/db.php');

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../vendor/autoload.php';


$message = '';
$otpSent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $conn->real_escape_string($_POST['email']);

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Generate OTP
        $otp = rand(100000, 999999);

        // Store in session
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_otp'] = $otp;

        // Send Email
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 's23_shaikh_irafan@mgmcen.ac.in';       // Your email
            $mail->Password   = 'oecy ydlu rzps qihz';          // App Password from Gmail
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            $mail->setFrom('s23_shaikh_irafan@mgmcen.ac.in', 'AgroTrade');
            $mail->addAddress($email, $user['name']);

            $mail->isHTML(true);
            $mail->Subject = 'Password Reset OTP - AgroTrade';
            $mail->Body    = "Hi <strong>{$user['name']}</strong>,<br><br>Your OTP to reset password is: <strong>$otp</strong>.<br>Use it on the reset password page.";

            $mail->send();
            $otpSent = true;
            $message = "OTP sent to your email. Please check your inbox.";
        } catch (Exception $e) {
            $message = "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $message = "Email not found in our records.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password - AgroTrade</title>
    <style>
        body {
            font-family: sans-serif;
            padding: 30px;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 8px rgba(0,0,0,0.2);
        }

        input[type="email"], button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            font-size: 16px;
        }

        .message {
            margin-top: 15px;
            font-weight: bold;
            color: #d9534f;
        }

        .success {
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <?php if ($message): ?>
            <p class="message <?= $otpSent ? 'success' : '' ?>"><?= $message ?></p>
        <?php endif; ?>

        <?php if (!$otpSent): ?>
        <form method="POST">
            <label>Enter your registered email:</label>
            <input type="email" name="email" required placeholder="Enter Email">
            <button type="submit">Send OTP</button>
        </form>
        <?php else: ?>
            <p><a href="reset_password.php">Click here to enter OTP and reset password</a></p>
        <?php endif; ?>
    </div>
</body>
</html>
