<?php include('../includes/db.php'); ?>
<?php include('../includes/header.php'); ?>
<?php
// Show "Admin Panel" button if the logged-in user is the admin
if (
    isset($_SESSION['user_type'], $_SESSION['user_email']) &&
    $_SESSION['user_type'] === 'buyer' &&
    $_SESSION['user_email'] === 'sheikhirafanrashid@gmail.com'
) {
    echo '<a href="../admin/index.php" class="admin-btn">⚙️ Admin Panel</a>';
}
?>


<main>
    <section class="hero">
        <div class="container">
            <h1>Welcome to AgroTrade</h1>
            <p>Your trusted platform to buy & sell agricultural products</p>
            <div class="hero-buttons">
                <a href="product_list.php" class="btn">Shop Now</a>
                <a href="sell.php" class="btn btn-outline">Sell Products</a>
            </div>
        </div>
    </section>

    <section class="features">
        <div class="container grid-3">
            <a href="../pages/sell.php" class="Link">
                <div class="feature-box">
                    <img src="../assets/images/Farmer.jpeg" alt="Farmers">
                    <h3>For Farmers</h3>
                    <p>List your fresh produce directly and get fair prices without middlemen.</p>
                </div>
            </a>
            <a href="../pages/product_list.php" class="Link">
                <div class="feature-box">
                    <img src="../assets/images/Buyer.jpeg" alt="Buyers">
                    <h3>For Buyers</h3>
                    <p>Buy fresh farm products directly from trusted farmers across India.</p>
                </div>
            </a>
            <a href="../pages/mandi_rates.php" class="Link">
                <div class="feature-box">
                    <img src="../assets/images/Rate.jpeg" alt="Rates">
                    <h3>Mandi Rates</h3>
                    <p>Track the latest mandi prices for commodities across Indian markets.</p>
                </div>
            </a>
        </div>
    </section>
</main>

<style>
    a img {
        display: inline;
        height: 30px;
        width: 50px;
    }

    .admin-btn {
        display: inline-block;
        padding: 10px 20px;
        background-color: #2e7d32;
        color: white;
        text-decoration: none;
        border-radius: 5px;
        margin-top: 20px;
        font-weight: bold;
        transition: background 0.3s;
    }

    .admin-btn:hover {
        background-color: #1b5e20;
    }

    body {
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f1f1f1 url('/AgroEcommerce/assets/images/background.jpeg') no-repeat center center/cover;
    }


    .hero {
        background: url('/AgroEcommerce/assets/images/hero-bg.jpg') no-repeat center center/cover;
        color: white;
        padding: 100px 20px;
        text-align: center;
    }

    .hero h1 {
        font-size: 3rem;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px #000;
    }

    .hero p {
        font-size: 1.2rem;
        margin-bottom: 30px;
        text-shadow: 1px 1px 3px #000;
    }

    .hero-buttons {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        gap: 15px;
    }

    .hero-buttons .btn {
        padding: 12px 28px;
        border-radius: 30px;
        font-weight: bold;
        font-size: 1rem;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .btn {
        background: #2e7d32;
        color: white;
        border: none;
    }

    .btn:hover {
        background: #1b5e20;
    }

    .btn-outline {
        background: transparent;
        border: 2px solid white;
        color: white;
    }

    .btn-outline:hover {
        background: white;
        color: #2e7d32;
    }

    .features {
        padding: 60px 20px;
        background-color: #ffffff;
    }

    .grid-3 {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 30px;
    }

    .feature-box {

        text-decoration: none;
        background: #fafafa;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: transform 0.3s ease;
    }

    .feature-box:hover {
        transform: translateY(-5px);
    }

    .feature-box img {
        height: 70px;
        margin-bottom: 15px;
    }

    .feature-box h3 {
        font-size: 1.4rem;
        margin-bottom: 10px;
        color: #2e7d32;
    }

    .feature-box p {
        font-size: 0.95rem;
        color: #333;
    }

    @media (max-width: 600px) {
        .hero h1 {
            font-size: 2rem;
        }

        .hero p {
            font-size: 1rem;
        }

        .hero-buttons .btn {
            width: 100%;
            max-width: 250px;
        }

        .feature-box img {
            height: 60px;
        }

        .feature-box h3 {
            font-size: 1.2rem;
        }

        .feature-box p {
            font-size: 0.9rem;
        }
    }
</style>

<?php include('../includes/footer.php'); ?>