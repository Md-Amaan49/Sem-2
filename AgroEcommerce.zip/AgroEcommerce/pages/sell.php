<?php
session_start();
include('../includes/db.php');
include('../includes/header.php');

$message = '';

// Handle form submission (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check login & role
    if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_type'], ['seller', 'both',])) {
        $message = "❌ Please log in as Seller to add a product.";
    } else {
        $farmer_id = $_SESSION['user_id'];

        $title = $conn->real_escape_string($_POST["title"]);
        $desc = $conn->real_escape_string($_POST["description"]);
        $price = floatval($_POST["price"]);

        // Validate description length
        if (strlen($desc) > 100) {
            $message = "❌ Description must be 100 characters or less.";
        } elseif ($price <= 0) {
            $message = "❌ Price must be greater than 0.";
        } else {
            // Handle Image Upload
            $image_name = '';
            if (!empty($_FILES["image"]["name"])) {
                $image_name = time() . '_' . basename($_FILES["image"]["name"]);
                $target = "../uploads/" . $image_name;
                move_uploaded_file($_FILES["image"]["tmp_name"], $target);
            }

            $sql = "INSERT INTO products (title, description, price, image, farmer_id)
                    VALUES ('$title', '$desc', '$price', '$image_name', '$farmer_id')";

            if ($conn->query($sql)) {
                $message = "✅ Product added successfully!";
            } else {
                $message = "❌ Database Error: " . $conn->error;
            }
        }
    }
}
?>

<main class="container">
    <h2>🌾 Sell Your Product</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" enctype="multipart/form-data" class="sell-form">
        <label>Product Title:</label>
        <input type="text" name="title" required placeholder="Enter product name">

        <label>Description (max 100 characters):</label>
        <textarea name="description" maxlength="100" required placeholder="Enter product details..."></textarea>

        <label>Price (in ₹ per Kg):</label>
        <input type="number" name="price" step="0.01" min="1" required placeholder="Enter price">

        <label>Upload Image:</label>
        <input type="file" name="image" accept="image/*" required>

        <button type="submit">Add Product</button>
    </form>
</main>

<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f9f9f9;
            background: #f1f1f1 url('/AgroEcommerce/assets/images/sell.png') no-repeat center center/cover;

}
.container {
    padding: 20px;
    max-width: 600px;
    margin: auto;
}
h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #2e7d32;
}
.sell-form {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    gap: 12px;
}
.sell-form label {
    font-weight: bold;
    margin-top: 10px;
}
.sell-form input,
.sell-form textarea {
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
}
.sell-form button {
    padding: 10px;
    background-color: #2e7d32;
    color: white;
    font-weight: bold;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: background 0.3s ease;
    margin-top: 10px;
}
.sell-form button:hover {
    background-color: #1b5e20;
}
.message {
    text-align: center;
    font-weight: bold;
    margin-bottom: 15px;
    color: #d32f2f;
}
@media (max-width: 600px) {
    .sell-form {
        padding: 15px;
    }
    .container {
        padding: 10px;
    }
    h2 {
        font-size: 22px;
    }
    .sell-form input,
    .sell-form textarea {
        font-size: 13px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>
