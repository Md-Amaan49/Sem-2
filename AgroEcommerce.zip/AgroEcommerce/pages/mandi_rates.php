<?php include('../includes/db.php'); ?>
<?php include('../includes/header.php'); ?>

<main class="container">
    <h2>📈 Live Mandi Rates</h2>
    <p id="Par">Prices listed below are manually added by admin and reflect approximate market values.</p>

    <div class="table-container">
        <table class="mandi-table">
            <thead>
                <tr>
                    <th>Crop</th>
                    <th>Market</th>
                    <th>Min Price (₹/quintal)</th>
                    <th>Max Price (₹/quintal)</th>
                    <th>Modal Price (₹/quintal)</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $rates = $conn->query("SELECT * FROM mandi_rates ORDER BY date_added DESC");
                if ($rates->num_rows > 0) {
                    while ($row = $rates->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['crop']}</td>
                            <td>{$row['market']}</td>
                            <td>₹{$row['min_price']}</td>
                            <td>₹{$row['max_price']}</td>
                            <td>₹{$row['modal_price']}</td>
                            <td>" . date('d M Y', strtotime($row['date_added'])) . "</td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No Mandi rates available at the moment.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</main>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: 'Segoe UI', sans-serif;
        background-color: #f9f9f9;
        background: #f1f1f1 url('/AgroEcommerce/assets/images/Feedback.png') no-repeat center center/cover;

    }

    main.container {
        max-width: 1100px;
        margin: 30px auto;
        padding: 20px;
    }

    h2 {
        text-align: center;
        color:rgb(0, 5, 0);
        margin-bottom: 10px;
        font-size: 28px;
    }

    #Par {
        text-align: center;
        margin-bottom: 25px;
        font-size: 15px;
        color:#ccc;
    }

    .table-container {
        overflow-x: auto;
        background: white;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .mandi-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 700px;
    }

    .mandi-table th,
    .mandi-table td {
        border: 1px solid #ccc;
        padding: 12px;
        text-align: center;
        font-size: 15px;
    }

    .mandi-table th {
        background-color: #e8f5e9;
        color: #2e7d32;
        font-weight: bold;
    }

    .mandi-table tr:nth-child(even) {
        background-color: #f4f4f4;
    }

    .mandi-table tr:hover {
        background-color: #f1f1f1;
    }

    @media (max-width: 768px) {
        h2 {
            font-size: 22px;
        }

        p {
            font-size: 14px;
        }

        .mandi-table th,
        .mandi-table td {
            font-size: 13px;
            padding: 10px 6px;
        }
    }

    @media (max-width: 480px) {
        .mandi-table {
            font-size: 12px;
            min-width: unset;
        }

        .mandi-table th,
        .mandi-table td {
            padding: 8px 5px;
        }

        main.container {
            padding: 10px;
        }
    }
</style>

<?php include('../includes/footer.php'); ?>