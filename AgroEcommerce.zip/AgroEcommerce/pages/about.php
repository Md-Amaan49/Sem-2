<?php include('../includes/header.php'); ?>

<main class="about-container">
    <h1>🌿 About AgroTrade</h1>

    <section class="about-section">
        <h2>Who We Are</h2>
        <p>AgroTrade is an innovative agricultural e-commerce platform designed to bridge the gap between farmers and buyers. Our mission is to empower farmers by giving them direct access to markets and help buyers find quality farm products at competitive prices.</p>
    </section>

    <section class="about-section">
        <h2>Our Vision</h2>
        <p>We envision a transparent, fair, and technology-driven marketplace for agriculture where every farmer can thrive and every consumer can trust what they buy.</p>
    </section>

    <section class="about-section">
        <h2>What We Offer</h2>
        <ul>
            <li>🌾 Direct listing of agro-products by farmers</li>
            <li>📈 Live Mandi Rates to stay updated on prices</li>
            <li>🛒 Secure shopping cart and easy checkout</li>
            <li>🔐 OTP-based secure registration and login</li>
            <li>🧾 Order tracking and invoice generation</li>
        </ul>
    </section>

    <section class="about-section">
        <h2>Who Can Use This Platform?</h2>
        <p><strong>Farmers:</strong> Register and list your products for sale.<br>
           <strong>Buyers:</strong> Browse, compare and purchase agricultural goods.<br>
           <strong>Admins:</strong> Manage users, products, and maintain platform quality.</p>
    </section>

    <section class="about-section">
        <h2>Contact Us</h2>
        <p>If you have any questions or feedback, feel free to <a href="contact.php">contact us</a>. We’re here to help!</p>
    </section>
</main>

<style>
.about-container {
    max-width: 800px;
    margin: auto;
    padding: 30px;
    font-family: Arial, sans-serif;
    line-height: 1.6;
    background-color: #fff;
}
.about-container h1 {
    text-align: center;
    margin-bottom: 30px;
}
.about-section {
    margin-bottom: 25px;
}
.about-section h2 {
    color: #2c3e50;
    margin-bottom: 10px;
}
.about-section ul {
    list-style: none;
    padding-left: 0;
}
.about-section ul li::before {
    content: "✅ ";
    color: green;
}
a {
    color: #28a745;
    text-decoration: none;
}
a:hover {
    text-decoration: underline;
}
</style>

<?php include('../includes/footer.php'); ?>
