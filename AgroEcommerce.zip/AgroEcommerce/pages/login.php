<?php
session_start();
include('../includes/db.php');

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST["email"]);
    $password = $_POST["password"];

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];

            if ($user['user_type'] === 'seller') {
                header("Location: sell.php");
            } else {
                header("Location: product_list.php");
            }
            exit();
        } else {
            $message = "Invalid password.";
        }
    } else {
        $message = "User not found.";
    }
}

include('../includes/header.php');
?>

<main class="container">
    <h2>Login</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" class="login-form">
        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Password:</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register here</a>.</p>
    <p><a href="forgot_password.php">Forgot Password?</a></p>
</main>

<style>
.container {
    padding: 20px;
    max-width: 600px;
    margin: auto;
}

.login-form {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.login-form input {
    padding: 10px;
    font-size: 16px;
}

button {
    padding: 10px;
    background-color: green;
    color: white;
    border: none;
    cursor: pointer;
}

.message {
    color: red;
    font-weight: bold;
}

@media (max-width: 500px) {
    .container {
        padding: 15px;
    }

    .login-form input, .login-form button {
        font-size: 14px;
        padding: 8px;
    }
}
</style>

<?php include('../includes/footer.php'); ?>
