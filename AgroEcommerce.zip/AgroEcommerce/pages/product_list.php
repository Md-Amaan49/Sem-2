<?php include('../includes/db.php'); ?>
<?php include('../includes/header.php'); ?>

<main class="container">
    <h2 class="section-title">Available Products</h2>

    <div class="product-grid">
        <?php
        $sql = "SELECT p.*, u.name AS farmer_name 
                FROM products p 
                JOIN users u ON p.farmer_id = u.id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
                <div class="product-card">
                    <img src="/AgroEcommerce/uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['title']; ?>">
                    <div class="product-info">
                        <h3><?php echo $row['title']; ?></h3>
                        <p class="desc"><?php echo $row['description']; ?></p>
                        <p><strong>Price:</strong> ₹<?php echo $row['price']; ?></p>
                        <p class="farmer"><small>By: <?php echo $row['farmer_name']; ?></small></p>
                        <div class="product-actions">
                            <a href="product_detail.php?id=<?php echo $row['id']; ?>" class="btn btn-view">View</a>

                            <form method="POST" action="/AgroEcommerce/pages/add_to_cart.php">
                                <input type="hidden" name="product_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="quantity" value="1">
                                <button type="submit" class="btn btn-cart">Add to Cart</button>
                            </form>
                        </div>

                    </div>
                </div>
            <?php endwhile;
        else: ?>
            <div class="no-products">
                <img src="background.jpeg" alt="No products available">
                <p>No products listed yet.</p>
            </div>
        <?php endif; ?>
    </div>
</main>

<style>
    body {
    margin: 0;
    padding: 0;
    font-family: 'Segoe UI', sans-serif;
    background: #f9f9f9;
}

.container {
    padding: 20px;
    max-width: 1200px;
    margin: auto;
}

.section-title {
    text-align: center;
    margin-bottom: 25px;
    color: #2f532f;
    font-size: 28px;
}

.product-grid {
    display: grid;
    gap: 25px;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.product-card {
    background: white;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    transition: transform 0.3s ease;
}

.product-card:hover {
    transform: translateY(-4px);
}

.product-card img {
    width: 100%;
    height: 180px;
    object-fit: cover;
}

.product-info {
    padding: 15px;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.product-info h3 {
    margin: 0 0 10px;
    font-size: 18px;
    color: #333;
}

.desc {
    color: #555;
    font-size: 14px;
    flex-grow: 1;
    margin-bottom: 10px;
}

.farmer {
    font-size: 13px;
    color: #888;
    margin-bottom: 10px;
}

.product-actions {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
    margin-top: auto;
}

.btn {
    padding: 8px 14px;
    font-size: 14px;
    color: white;
    border: none;
    border-radius: 20px;
    text-decoration: none;
    text-align: center;
    cursor: pointer;
    transition: background 0.3s ease;
}

.btn-view {
    background-color: #3d6b3d;
}

.btn-view:hover {
    background-color: #2a4d2a;
}

.btn-cart {
    background-color: #2e7d32;
}

.btn-cart:hover {
    background-color: #1b5e20;
}

.no-products {
    text-align: center;
    padding: 40px;
    color: #666;
}

.no-products img {
    max-width: 200px;
    margin-bottom: 20px;
}
@media (max-width: 768px) {
    .section-title {
        font-size: 24px;
    }

    .product-info h3 {
        font-size: 16px;
    }

    .btn {
        font-size: 13px;
        padding: 8px 12px;
    }
}

@media (max-width: 480px) {
    .product-actions {
        flex-direction: column;
    }

    .btn {
        width: 100%;
        padding: 10px;
        font-size: 14px;
    }

    .product-card img {
        height: 160px;
    }

    .product-info h3 {
        font-size: 15px;
    }

    .desc {
        font-size: 13px;
    }
}
</style>
<?php include('../includes/footer.php'); ?>