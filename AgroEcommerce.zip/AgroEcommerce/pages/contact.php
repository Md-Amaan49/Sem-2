<?php
include('../includes/db.php'); // adjust path as needed
include('../includes/header.php');

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $subject = $conn->real_escape_string($_POST["subject"]);
    $msg = $conn->real_escape_string($_POST["message"]);

    $sql = "INSERT INTO contact_messages (name, email, subject, message)
            VALUES ('$name', '$email', '$subject', '$msg')";

    if ($conn->query($sql)) {
        $message = "✅ Your message has been submitted successfully!";
    } else {
        $message = "❌ Something went wrong. Please try again.";
    }
}
?>

<main class="container">
    <h2 class="Head">📞 Contact Us</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" class="contact-form">
        <label>Name:</label>
        <input type="text" name="name" required placeholder="Enter your name">

        <label>Email:</label>
        <input type="email" name="email" required placeholder="Enter your email">

        <label>Subject:</label>
        <input type="text" name="subject" required placeholder="Enter subject">

        <label>Message:</label>
        <textarea name="message" required placeholder="Enter your Message"></textarea>

        <button type="submit">Send Message</button>
    </form>
</main>

<style>
    .container{
        margin-bottom: 20px;
    }
    .contact-form {
        max-width: 600px;
        margin: auto;
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    .Head{
        text-align: center;
    }

    .contact-form input,
    .contact-form textarea {
        padding: 10px;
        font-size: 14px;
        border-radius: 6px;
        border: 1px solid #ccc;
    }

    .contact-form button {
        padding: 10px;
        background-color: #2e7d32;
        color: white;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .contact-form button:hover {
        background-color: #1b5e20;
    }

    .message {
        text-align: center;
        font-weight: bold;
        color: green;
        margin-bottom: 10px;
    }
</style>

<?php include('../includes/footer.php'); ?>
