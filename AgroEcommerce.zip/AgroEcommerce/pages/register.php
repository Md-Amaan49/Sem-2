<?php
session_start();
include('../includes/db.php');
require '../includes/mailer.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    $user_type = $conn->real_escape_string($_POST['user_type']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $otp = rand(100000, 999999);

    $check_email = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($check_email->num_rows > 0) {
        $message = "Email already registered.";
    } else {
        $sql = "INSERT INTO users (name, email, phone, address, password, user_type, otp, is_verified)
                VALUES ('$name', '$email', '$phone', '$address', '$password', '$user_type', '$otp', 0)";

        if ($conn->query($sql) === TRUE) {
            $subject = "AgroTrade OTP Verification";
            $body = "Your OTP code is: <strong>$otp</strong>";

            if (sendEmail($email, $subject, $body, $name)) {
                $_SESSION['temp_email'] = $email;
                header("Location: otp_verification.php");
                exit();
            } else {
                $message = "Failed to send OTP. Please try again.";
            }
        } else {
            $message = "Registration failed. Try again.";
        }
    }
}
?>

<?php include('../includes/header.php'); ?>

<main class="container">
    <h2 class="title">Register</h2>
    <?php if ($message) echo "<p class='message'>$message</p>"; ?>

    <form method="POST" class="register-form">
        <label>Name:</label>
        <input type="text" name="name" required>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Phone:</label>
        <input type="text" name="phone" required>

        <label>Address:</label>
        <textarea name="address" required></textarea>

        <label>Password:</label>
        <input type="password" name="password" required>

        <select name="user_type" required>
            <option value="">-- Select User Type --</option>
            <option value="buyer" <?= (isset($_POST['user_type']) && $_POST['user_type'] == 'buyer') ? 'selected' : '' ?>>Buyer</option>
            <option value="seller" <?= (isset($_POST['user_type']) && $_POST['user_type'] == 'seller') ? 'selected' : '' ?>>Seller</option>
            <option value="both" <?= (isset($_POST['user_type']) && $_POST['user_type'] == 'both') ? 'selected' : '' ?>>Both</option>
        </select>

        <button type="submit">Register</button>
    </form>

    <p class="login-link">Already have an account? <a href="login.php">Login here</a>.</p>
</main>

<style>
    .title {
        text-align: center;
        margin-bottom: 20px;
        font-size: 28px;
        color: #2e7d32;
    }

    .register-form {
        max-width: 500px;
        margin: auto;
        display: flex;
        flex-direction: column;
        margin-bottom: 20px;
    }

    .register-form input,
    .register-form textarea,
    .register-form select {
        padding: 10px;
        margin: 8px 0;
        border: 1px solid #ccc;
        border-radius: 6px;
    }

    .register-form button {
        padding: 10px;
        background-color: #2e7d32;
        color: white;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .register-form button:hover {
        background-color: #1b5e20;
    }

    .message {
        color: red;
        font-weight: bold;
        text-align: center;
    }

    .login-link {
        text-align: center;
        margin-top: 10px;
        font-size: 14px;
    }
</style>

<?php include('../includes/footer.php'); ?>