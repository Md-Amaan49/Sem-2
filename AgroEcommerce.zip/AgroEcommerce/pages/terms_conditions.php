<?php include('../includes/header.php'); ?>
<main class="container">
    <h2>Terms & Conditions</h2>
    <p>Please read these terms and conditions carefully before using our website:</p>
    <ul>
        <li>All transactions must comply with Indian laws and regulations.</li>
        <li>Prices and availability of products are subject to change without notice.</li>
        <li>We reserve the right to cancel any order if payment or product availability issues arise.</li>
        <li>Users are responsible for maintaining account security and accurate information.</li>
    </ul>
    <p>Using our platform implies you agree to these terms.</p>
</main>

<style>
.container {
    max-width: 900px;
    margin: auto;
    padding: 20px;
    font-family: Arial, sans-serif;
}
</style>
<?php include('../includes/footer.php'); ?>
