<?php
include('../includes/db.php');
include('../includes/header.php');

$submit_msg = "";

// Insert feedback if form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $conn->real_escape_string($_POST["name"]);
    $email = $conn->real_escape_string($_POST["email"]);
    $message = $conn->real_escape_string($_POST["message"]);

    $sql = "INSERT INTO feedback (name, email, message) VALUES ('$name', '$email', '$message')";
    if ($conn->query($sql)) {
        $submit_msg = "✅ Thank you for your feedback!";
    } else {
        $submit_msg = "❌ Error submitting feedback. Please try again.";
    }
}

// Fetch latest 5 feedback
$feedbacks = [];
$result = $conn->query("SELECT name, message, submitted_at FROM feedback ORDER BY submitted_at DESC LIMIT 5");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $feedbacks[] = $row;
    }
}
?>

<main class="container">
    <h2 style="text-align: center;">📝 Give Us Your Feedback</h2>

    <?php if ($submit_msg) echo "<p class='message'>$submit_msg</p>"; ?>

    <form method="POST" class="feedback-form">
        <label>Name:</label>
        <input type="text" name="name" required placeholder="Your Name">

        <label>Email:</label>
        <input type="email" name="email" required placeholder="Your Email">

        <label>Message:</label>
        <textarea name="message" required placeholder="Your feedback here..."></textarea>

        <button type="submit">Submit Feedback</button>
    </form>

    <?php if (!empty($feedbacks)): ?>
        <div class="feedback-display">
            <h3>⭐ Recent Feedback</h3>
            <?php foreach ($feedbacks as $fb): ?>
                <div class="feedback-card">
                    <p><strong><?php echo htmlspecialchars($fb['name']); ?></strong></p>
                    <p><?php echo htmlspecialchars($fb['message']); ?></p>
                    <p class="date"><?php echo date('d M Y, h:i A', strtotime($fb['submitted_at'])); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<style>
   
    .feedback-form {
        max-width: 600px;
        margin: auto;
        background: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-bottom: 30px;
    }

    .feedback-form input,
    .feedback-form textarea {
        padding: 10px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 6px;
    }

    .feedback-form button {
        background-color: #2e7d32;
        color: white;
        padding: 10px;
        font-weight: bold;
        border: none;
        border-radius: 6px;
        cursor: pointer;
    }

    .feedback-form button:hover {
        background-color: #1b5e20;
    }

    .message {
        text-align: center;
        font-weight: bold;
        color: green;
        margin-bottom: 15px;
    }

    .feedback-display {
        max-width: 700px;
        margin: auto;
        padding: 10px;
    }

    .feedback-display h3 {
        text-align: center;
        margin-bottom: 20px;
    }

    .feedback-card {
        background: #f1f1f1;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 15px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .feedback-card .date {
        font-size: 12px;
        color: #666;
        margin-top: 5px;
    }

    @media (max-width: 600px) {
        .feedback-form, .feedback-display {
            padding: 10px;
        }
    }
</style>

<?php include('../includes/footer.php'); ?>
