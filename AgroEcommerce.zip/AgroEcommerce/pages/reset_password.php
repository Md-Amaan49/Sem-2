<?php
session_start();
include('../includes/db.php');

$message = '';

if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_otp'])) {
    header("Location: forgot_password.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $enteredOtp = $_POST['otp'];
    $newPassword = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($enteredOtp != $_SESSION['reset_otp']) {
        $message = "❌ Invalid OTP. Please try again.";
    } elseif ($newPassword !== $confirmPassword) {
        $message = "❌ Passwords do not match.";
    } else {
        $email = $_SESSION['reset_email'];
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        $sql = "UPDATE users SET password='$hashedPassword' WHERE email='$email'";
        if ($conn->query($sql)) {
            $message = "✅ Password reset successfully! You can now <a href='login.php'>login</a>.";
            // Clear session values
            unset($_SESSION['reset_email']);
            unset($_SESSION['reset_otp']);
        } else {
            $message = "❌ Failed to reset password. Try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password - AgroTrade</title>
    <style>
        body {
            font-family: sans-serif;
            padding: 30px;
            background-color: #f9f9f9;
        }

        .container {
            max-width: 500px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0px 0px 8px rgba(0,0,0,0.2);
        }

        input[type="text"], input[type="password"], button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            font-size: 16px;
        }

        .message {
            margin-top: 15px;
            font-weight: bold;
            color: #d9534f;
        }

        .success {
            color: green;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Your Password</h2>

        <?php if ($message): ?>
            <p class="message <?= strpos($message, '✅') !== false ? 'success' : '' ?>"><?= $message ?></p>
        <?php endif; ?>

        <form method="POST">
            <label>Enter OTP:</label>
            <input type="text" name="otp" required placeholder="6-digit OTP">

            <label>New Password:</label>
            <input type="password" name="password" required placeholder="New Password">

            <label>Confirm New Password:</label>
            <input type="password" name="confirm_password" required placeholder="Confirm Password">

            <button type="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
