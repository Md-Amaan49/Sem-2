<?php
$host = 'localhost';
$dbname = 'agro_ecommerce';  // your database name
$user = 'root';
$pass = '';  // usually blank in XAMPP

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    // Set error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
