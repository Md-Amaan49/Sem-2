// cart.js

document.addEventListener('DOMContentLoaded', function () {
    const buttons = document.querySelectorAll('.add-to-cart');

    buttons.forEach(button => {
        button.addEventListener('click', function (e) {
            e.preventDefault();
            const productId = this.dataset.id;

            fetch(`cart.php?action=add&id=${productId}`)
                .then(res => res.text())
                .then(data => {
                    alert('✅ Product added to cart!');
                    updateCartCount();
                });
        });
    });

    function updateCartCount() {
        fetch('cart_count.php')
            .then(res => res.text())
            .then(count => {
                document.getElementById('cart-count').textContent = count;
            });
    }
});
