<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>AgroTrade - Agri E-Commerce</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Buy and sell agri products, check mandi rates, connect farmers and buyers.">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="icon" type="image/png" href="/AgroEcommerce/assets/images/logo.png">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .main-header {
            position: sticky;
            top: 0;
            z-index: 999;
            background: #f6f6f6;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .main-header .container {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            justify-content: space-between;
            max-width: 1400px;
            padding: 10px 20px;
            margin: auto;
        }

        .logo-section {
            display: flex;
            align-items: center;
        }

        .logo-img {
            height: 40px;
            margin-right: 10px;
        }

        .site-title {
            font-size: 28px;
            font-weight: bold;
            color: #3d6b3d;
            font-family: cursive;
        }

        .nav-toggle {
            display: none;
            font-size: 26px;
            cursor: pointer;
            background: none;
            border: none;
            color: #333;
        }

        .nav-menu,
        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        .nav-menu a,
        .header-actions a {
            text-decoration: none;
            color: #333;
            font-weight: bold;
            font-family: monospace;
            font-size: 16px;
        }

        .search-box {
            padding: 8px 12px;
            border-radius: 20px;
            border: 2px solid #153f1a;
            font-family: monospace;
            text-transform: uppercase;
            width: 160px;
        }

        .btn-login,
        .btn-register,
        .btn-cart,
        .btn-order {
            background-color: #153f1a;
            color: white;
            padding: 8px 14px;
            border-radius: 20px;
            font-family: monospace;
            font-size: 14px;
        }

        .btn-profile {
            background-color: #0d2f0f;
            padding: 6px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .user-icon {
            height: 24px;
            width: 24px;
            border-radius: 50%;
        }
        .user-icon:hover {
            cursor: pointer;
        }

        #Cart,
        #Login,
        #Logout,
        #Register,
        #My_O {
            color: #f6f6f6;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 45px;
            right: 0;
            background-color: white;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            border-radius: 6px;
            z-index: 1000;
            flex-direction: column;
            min-width: 120px;
        }

        .dropdown-menu a {
            padding: 10px;
            color: #333;
            text-align: left;
            font-size: 14px;
        }

        .dropdown-menu a:hover {
            background-color: #f1f1f1;
        }

        .btn-profile:hover .dropdown-menu {
            display: flex;
        }
        

        .dropdown-menu:hover{
            cursor: pointer;

        }

        /* Medium screens fix */
        @media (max-width: 1199px) {
            .main-header .container {
                flex-direction: column;
                align-items: flex-start;
            }

            .nav-menu,
            .header-actions {
                flex-wrap: wrap;
                justify-content: center;
                width: 100%;
                margin-top: 10px;
            }

            .search-box {
                width: 100%;
                max-width: 260px;
            }
        }

        /* Mobile screens */
        @media (max-width: 768px) {

            .nav-menu,
            .header-actions {
                display: none;
                width: 100%;
                flex-direction: column;
                background-color: #f6f6f6;
                padding: 10px 0;
            }

            .nav-menu.show,
            .header-actions.show {
                display: flex;
            }

            .nav-toggle {
                display: block;
            }

            .dropdown-menu {
                position: static;
                display: none;
                width: 100%;
            }

            .btn-profile.show .dropdown-menu {
                display: flex;
            }
        }
    </style>

</head>

<body>
    <header class="main-header">
        <div class="container">
            <div class="logo-section">
                <button class="nav-toggle" onclick="toggleHeader()">&#9776;</button>
                <img src="/AgroEcommerce/assets/images/logo2.jpg" alt="Logo" class="logo-img">
                <span class="site-title">Agrotrade</span>
            </div>

            <nav class="nav-menu" id="navMenu">
                <a href="/AgroEcommerce/pages/home.php">Home</a>
                <a href="/AgroEcommerce/pages/product_list.php">Products</a>
                <a href="/AgroEcommerce/pages/sell.php">Sell</a>
                <a href="/AgroEcommerce/pages/mandi_rates.php">Mandi Rates</a>
                <a href="/AgroEcommerce/pages/about.php">About</a>
            </nav>

            <div class="header-actions" id="headerActions">
                <form action="/AgroEcommerce/pages/search_result.php" method="GET">
                    <input type="text" name="query" class="search-box" placeholder="SEARCH">
                </form>
                <a href="/AgroEcommerce/pages/cart.php" class="btn-cart" id="Cart">Cart</a>
                <a href="/AgroEcommerce/pages/my_orders.php" class="btn-order " id="My_O">My Order</a>

                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/AgroEcommerce/pages/logout.php" class="btn-login " id="Logout">Logout</a>
                <?php else: ?>
                    <a href="/AgroEcommerce/pages/login.php" class="btn-login " id="Login">Login</a>
                    <!-- <a href="/AgroEcommerce/pages/register.php" class="btn-register " id="Register">Register</a> -->
                <?php endif; ?>

                <div class="btn-profile" onclick="toggleDropdown()">
                    <img src="/AgroEcommerce/assets/images/profile.webp" alt="Profile" class="user-icon">
                    <div class="dropdown-menu" id="dropdownMenu">
                        <a href="/AgroEcommerce/profile.php">My Profile</a>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <a href="/AgroEcommerce/pages/logout.php">Logout</a>
                        <?php else: ?>
                            <a href="/AgroEcommerce/pages/login.php">Login</a>
                            <a href="/AgroEcommerce/pages/register.php">Register</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <script>
        function toggleHeader() {
            document.getElementById('navMenu').classList.toggle('show');
            document.getElementById('headerActions').classList.toggle('show');
        }

        function toggleDropdown() {
            const dropdown = document.getElementById("dropdownMenu");
            dropdown.style.display = dropdown.style.display === "flex" ? "none" : "flex";
        }

        // Optional: close dropdown on outside click
        window.addEventListener('click', function(e) {
            if (!e.target.closest('.btn-profile')) {
                document.getElementById("dropdownMenu").style.display = "none";
            }
        });
    </script>
</body>

</html>