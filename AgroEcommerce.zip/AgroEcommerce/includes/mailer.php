<?php
require '../vendor/autoload.php'; // This is essential

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendEmail($toEmail, $subject, $bodyHtml, $toName)
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 's23_shaikh_irafan@mgmcen.ac.in';         // Your Gmail
        $mail->Password   = 'oecy ydlu rzps qihz';            // App password from Google
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use STARTTLS
        $mail->Port       = 587;

        $mail->setFrom('s23_shaikh_irafan@mgmcen.ac.in', 'AgroTrade');
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $bodyHtml;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}
